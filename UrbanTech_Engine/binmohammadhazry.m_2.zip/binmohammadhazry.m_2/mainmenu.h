#pragma once

void Main_Menu_Init(void);
void Main_Menu_Update(void);
void Main_Menu_Exit(void);
void Draw_Rectangle(void);
void Debug_Tools(void);